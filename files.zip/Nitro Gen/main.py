import os
import time
import sys
from functions.functions import generate_nitro_code, check_nitro_code
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_centered(text, color=Fore.WHITE):
    terminal_width = os.get_terminal_size().columns
    print(color + text.center(terminal_width))

def save_valid_code(valid_code):
    with open("valid_codes.txt", "a") as file:
        file.write(valid_code + "\n")

def main():
    clear_console()
    os.system('color 0F')  # Set console background to black

    print_centered(f"{Fore.MAGENTA}{Style.BRIGHT}𝕵𝖔𝖒𝖆𝖓𝖏𝖎 𝕹𝖎𝖙𝖗𝖔 𝕲𝖊𝖓𝖊𝖗𝖆𝖙𝖔𝖗{Style.RESET_ALL}")
    print_centered(f"{Fore.MAGENTA}=============================")
    print_centered("1. Start", Fore.RED)
    print_centered("2. Close", Fore.RED)
    print_centered(f"{Fore.YELLOW}+ by joman21")
    print_centered(f"{Fore.MAGENTA}=============================")

    choice = input("Wählen Sie eine Option: ")

    if choice == '1':
        amount = int(input("Wie viele Codes sollen generiert werden? "))
        
        clear_console()
        os.system('color 0F')
        print_centered(f"{Fore.CYAN}Generiere und überprüfe Nitro-Codes...{Style.RESET_ALL}")

        valid_codes = []

        for _ in range(amount):
            code = generate_nitro_code()
            is_valid = check_nitro_code(code)
            status = f"{Fore.GREEN}valid ✅" if is_valid else f"{Fore.RED}invalid ❌"
            print(f"{Fore.CYAN}[+] generated nitro code: {code} | {status}{Style.RESET_ALL}")

            if is_valid:
                valid_codes.append(code)
                save_valid_code(code)

        if valid_codes:
            print(f"\n{Fore.GREEN}Gültige Codes: {', '.join(valid_codes)}")
        else:
            print(f"\n{Fore.RED}Keine gültigen Codes gefunden.")
    elif choice == '2':
        print(f"{Fore.RED}Beenden...")
    else:
        print(f"{Fore.RED}Ungültige Auswahl, bitte versuchen Sie es erneut.")

if __name__ == "__main__":
    main()
