import requests
import random
import string

def generate_nitro_code():
    return "https://discord.gift/" + ''.join(random.choices(string.ascii_letters + string.digits, k=16))

def check_nitro_code(code):
    url = "https://discordapp.com/api/v9/entitlements/gift-codes/" + code.split('/')[-1] + "?with_application=false&with_subscription_plan=true"
    response = requests.get(url)
    return response.status_code == 200
